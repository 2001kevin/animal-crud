
<?php $__env->startSection('content'); ?>
<form action="/store" method="POST">
    <?php echo csrf_field(); ?>
    <label for="tanggal">Tanggal:</label>
    <input type="date" id="tanggal" name="tanggal">
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel AnimalPost\resources\views/nyobatime.blade.php ENDPATH**/ ?>