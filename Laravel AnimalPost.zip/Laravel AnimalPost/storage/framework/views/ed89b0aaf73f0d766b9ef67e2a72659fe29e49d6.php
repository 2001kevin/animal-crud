

<?php $__env->startSection('title', 'Animal Crud'); ?>

<?php $__env->startSection('header', 'Animal List'); ?>

<?php $__env->startSection('content'); ?>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
    <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>
<a type="button" class="btn btn-primary" href="NewList">Add New List</a>

<table class="table">
    <thead>
      <tr>
        <th scope="col">No.</th>
        <th scope="col">Animal Image</th>
        <th scope="col">Animal Name</th>
        <th scope="col">Number of feet</th>
        <th scope="col">Animal Description</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $animals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
            <th scope="row"><?php echo e($loop->index+1+($animals->currentPage()-1)*5); ?></th>
            <td><img src="<?php echo e(asset('storage/' . $animal->image)); ?>" height="75" width="75" alt="" /></td>
            <td><?php echo e($animal->name); ?></td>
            <td><?php echo e($animal->number_of_feet); ?></td>
            <td><?php echo e(Str::limit($animal->description, 50)); ?></td>
            <td>
                <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                    <a type="button" class="btn btn-primary" href="/<?php echo e($animal -> id); ?>/Details">Details</a>
                    <a type="button" class="btn btn-success" href="/<?php echo e($animal -> id); ?>/Edit">Edit</a>
                    <a type="button" class="btn btn-danger" href="/<?php echo e($animal -> id); ?>/Delete">Delete</a>
                </div>
            </td>
            
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php echo e($animals->links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel AnimalPost\resources\views/animal/list.blade.php ENDPATH**/ ?>