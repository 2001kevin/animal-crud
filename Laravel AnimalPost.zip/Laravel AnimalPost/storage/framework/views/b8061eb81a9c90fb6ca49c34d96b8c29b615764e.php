

<?php $__env->startSection('title', 'Animal Crud'); ?>

<?php $__env->startSection('header', 'Animal Details'); ?>

<?php $__env->startSection('content'); ?>
    <div >
      <label for="name" class="form-label">Animal Image</label>
    </div>
      <img src="<?php echo e(asset('storage/' . $animals->image)); ?>" height="200" width="200" class="img-thumbnail" alt="...">
    <div class="mb-3 mt-3">
      <label for="name" class="form-label">Animal Name</label>
      <input type="text" class="form-control" id="name" name="name" value="<?php echo e($animals->name); ?>" readonly>
    </div>
    <div class="mb-3">
      <label for="name" class="form-label">Number of Feet</label>
      <input type="text" class="form-control" id="name" name="name" value="<?php echo e($animals->number_of_feet); ?>" readonly>
    </div>
    <div class="mb-3">
      <label for="exampleInputPassword1" class="form-label">Animal Description</label>
      <textarea  class="form-control" id="description" name="description" readonly><?php echo e($animals->description); ?></textarea>
    </div>
    <a type="button" class="btn btn-success" href="/">Back</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web-laravel\resources\views/animal/details.blade.php ENDPATH**/ ?>